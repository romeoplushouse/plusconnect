#!/bin/bash
# setup.sh – nainstaluj závislosti a připrav prostředí
set -e

echo "=== Previo-Loxone Sync Service Setup ==="

# Vytvoř virtualenv
if [ ! -d ".venv" ]; then
    echo "Vytvářím virtualenv..."
    python3 -m venv .venv
fi

source .venv/bin/activate

echo "Instaluji závislosti..."
pip install --upgrade pip
# Nainstaluj bez psycopg2 pokud nepoužíváš PostgreSQL
pip install requests SQLAlchemy alembic python-dotenv lxml schedule

echo ""
echo "Kopíruji .env.example → .env"
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "POZOR: Vyplň .env soubor svými credentials!"
fi

echo ""
echo "Vytváím složky..."
mkdir -p data logs

echo ""
echo "=== Setup hotov ==="
echo ""
echo "Další kroky:"
echo "  1. Vyplň .env soubor"
echo "  2. source .venv/bin/activate"
echo "  3. python main.py --check-health   # test připojení"
echo "  4. python main.py                  # jeden sync"
echo "  5. python main.py --daemon         # nepřetržitý sync"
