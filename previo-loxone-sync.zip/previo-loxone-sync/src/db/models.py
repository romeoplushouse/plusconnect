"""
db/models.py – SQLAlchemy ORM modely.
"""
from datetime import datetime
from sqlalchemy import (
    Column, String, Integer, DateTime, Text, Boolean, Index
)
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class Reservation(Base):
    __tablename__ = "reservations"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Previo identifikátory
    reservation_id = Column(String(64), unique=True, nullable=False, index=True)
    booking_id = Column(String(64), nullable=True)
    com_id = Column(String(64), nullable=True)          # ID pro Previo PIN API

    # Loxone
    loxone_user_uuid = Column(String(64), nullable=True, index=True)

    # PIN (nikdy neplaintext – ukládáme pouze SHA-256 hash)
    pin_hash = Column(String(64), nullable=True)        # SHA-256(pin)

    # Časy přístupu (Unix timestamp)
    pin_valid_from = Column(Integer, nullable=True)
    pin_valid_until = Column(Integer, nullable=True)

    # Info o hostovi
    guest_name = Column(String(256), nullable=True)
    room_identifier = Column(String(128), nullable=True)

    # Datumy pobytu (ISO string pro jednoduché uložení)
    checkin_date = Column(String(32), nullable=True)
    checkout_date = Column(String(32), nullable=True)

    # Stav rezervace z Previo
    reservation_status = Column(String(32), nullable=True)

    # Stav synchronizace
    # Hodnoty: pending | synced | sync_failed | cancelled_synced | stale
    sync_status = Column(String(32), nullable=False, default="pending", index=True)
    last_sync_at = Column(DateTime, nullable=True)
    last_error = Column(Text, nullable=True)
    retry_count = Column(Integer, nullable=False, default=0)
    next_retry_at = Column(DateTime, nullable=True)

    # Fingerprint pro detekci změn (SHA-256 klíčových polí)
    data_fingerprint = Column(String(64), nullable=True)
    pin_fingerprint = Column(String(64), nullable=True)

    # Timestamps
    first_seen_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    previo_updated_at = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_reservations_sync_status_retry", "sync_status", "next_retry_at"),
    )

    def __repr__(self):
        return (
            f"<Reservation reservation_id={self.reservation_id} "
            f"status={self.reservation_status} sync={self.sync_status}>"
        )


class SyncRun(Base):
    __tablename__ = "sync_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    finished_at = Column(DateTime, nullable=True)

    window_from = Column(DateTime, nullable=False)
    window_to = Column(DateTime, nullable=False)

    # Hodnoty: running | success | partial_failure | failed
    status = Column(String(32), nullable=False, default="running")

    count_fetched = Column(Integer, default=0)
    count_created = Column(Integer, default=0)
    count_updated = Column(Integer, default=0)
    count_cancelled = Column(Integer, default=0)
    count_skipped = Column(Integer, default=0)
    count_failed = Column(Integer, default=0)

    error_detail = Column(Text, nullable=True)

    def __repr__(self):
        return f"<SyncRun id={self.id} status={self.status} from={self.window_from}>"


class AuditLog(Base):
    __tablename__ = "audit_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    occurred_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)

    reservation_id = Column(String(64), nullable=True, index=True)
    loxone_user_uuid = Column(String(64), nullable=True)

    # Akce: CREATE_USER | UPDATE_PIN | EXTEND_VALIDITY | CANCEL_ACCESS |
    #        RETRY_FAILED | PIN_CHANGED | VALIDITY_CHANGED | DELETE_USER
    action = Column(String(64), nullable=False)

    old_value_hash = Column(String(64), nullable=True)
    new_value_hash = Column(String(64), nullable=True)

    triggered_by = Column(String(64), nullable=True, default="sync_service")

    # Výsledek: success | failure
    result = Column(String(16), nullable=False)
    detail = Column(Text, nullable=True)

    def __repr__(self):
        return f"<AuditLog action={self.action} result={self.result} reservation={self.reservation_id}>"
