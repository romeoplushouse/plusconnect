"""
db/database.py – SQLAlchemy engine, session factory a inicializace schématu.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from src.config import config
from src.db.models import Base

engine = create_engine(
    config.DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in config.DATABASE_URL else {},
    echo=False,
)

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def init_db() -> None:
    """Vytvoří tabulky pokud neexistují."""
    import os
    # Vytvoř složku pro SQLite soubor pokud neexistuje
    if "sqlite" in config.DATABASE_URL:
        db_path = config.DATABASE_URL.replace("sqlite:///", "")
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
    Base.metadata.create_all(bind=engine)


def get_session() -> Session:
    """Vrátí novou DB session. Volající je zodpovědný za uzavření."""
    return SessionLocal()
