"""
config.py – načítání konfigurace z .env
Nikdy neloguj hodnoty credentials.
"""
import os
from dotenv import load_dotenv

load_dotenv()


def _require(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise EnvironmentError(f"Povinná env proměnná '{key}' není nastavena.")
    return val


class Config:
    # Previo
    PREVIO_API_URL: str = _require("PREVIO_API_URL")
    PREVIO_USERNAME: str = _require("PREVIO_USERNAME")
    PREVIO_PASSWORD: str = _require("PREVIO_PASSWORD")
    PREVIO_HOTEL_ID: str = _require("PREVIO_HOTEL_ID")

    # Loxone
    LOXONE_BASE_URL: str = _require("LOXONE_BASE_URL").rstrip("/")
    LOXONE_USERNAME: str = _require("LOXONE_USERNAME")
    LOXONE_PASSWORD: str = _require("LOXONE_PASSWORD")
    LOXONE_GUEST_GROUP_UUID: str = _require("LOXONE_GUEST_GROUP_UUID")

    # DB
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./data/sync.db")

    # Sync
    SYNC_INTERVAL_SECONDS: int = int(os.getenv("SYNC_INTERVAL_SECONDS", "300"))
    SYNC_OVERLAP_BUFFER_MINUTES: int = int(os.getenv("SYNC_OVERLAP_BUFFER_MINUTES", "10"))
    SYNC_INITIAL_LOOKBACK_DAYS: int = int(os.getenv("SYNC_INITIAL_LOOKBACK_DAYS", "7"))
    SYNC_MAX_RETRY_COUNT: int = int(os.getenv("SYNC_MAX_RETRY_COUNT", "5"))

    # Retry backoff v sekundách
    RETRY_BACKOFF_SECONDS: list = [60, 300, 900, 3600, 7200]

    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "./logs/sync.log")


config = Config()
