"""
previo/client.py – HTTP klient pro Previo API (XML + REST).

=== searchReservations ===
POST https://api.previo.app/x1/hotel/searchReservations
Auth: <login> + <password> v XML těle
Format: vlastní Previo XML

=== card-locking-keys (PIN) ===
GET {PREVIO_API_URL}/rest/reservations/rooms/card-locking-keys?reservationRoomId={comId}
Auth: HTTP Basic Auth (stejný login/password jako XML API)
Headers: X-Previo-Hotel-ID: {hotId}
Response: JSON

Struktura XML odpovědi (ověřeno):
  <reservation>
    <comId>      – primární klíč = reservationRoomId pro PIN API
    <resId>      – ID skupiny rezervace (více pokojů = stejné resId)
    <term><from>/<to>  – "YYYY-MM-DD HH:MM:SS"
    <status><statusId> – 1=option, 2=confirmed, 3=cancelled
    <guest><name> nebo <firstName>+<lastName>
    <object><name> – název pokoje

Struktura PIN odpovědi (ověřeno):
  {
    "cardData": {
      "keys": [
        {
          "code": "1234",              – PIN plaintext
          "lockGuestName": "101",      – název zámku/pokoje
          "lockExternalName": null,
          "validity": {
            "from": "2024-12-10T14:00:00+0100",  – ISO 8601 s TZ
            "to":   "2024-12-11T10:00:00+0100"
          }
        }
      ]
    }
  }
  Jeden comId může mít více klíčů (více zámků = více pokojů v suite).
  Používáme první klíč (keys[0]).

StatusId mapování:
  1 = option      → aktivní přístup
  2 = confirmed   → aktivní přístup
  3 = cancelled   → odebrat přístup
  4 = no_show     → odebrat přístup
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from lxml import etree
import requests
from requests.auth import HTTPBasicAuth

from src.config import config
from src.utils.logger import logger


# ---------------------------------------------------------------------------
# Datové třídy
# ---------------------------------------------------------------------------

@dataclass
class PrevioReservation:
    com_id: str                     # <comId> = reservationRoomId pro PIN API
    res_id: str                     # <resId> – skupina rezervace
    guest_name: Optional[str]
    room_name: Optional[str]        # <object><name>
    checkin_dt: Optional[datetime]
    checkout_dt: Optional[datetime]
    status_id: int
    reservation_status: str         # "option"|"confirmed"|"cancelled"|"no_show"|"unknown"
    alfred_code: Optional[str]
    created_at: Optional[datetime]


@dataclass
class PrevioPin:
    pin: str                        # plaintext PIN (Loxone hashuje sám)
    lock_name: Optional[str]        # lockGuestName – název zámku
    valid_from: datetime            # validity.from jako aware datetime
    valid_until: datetime           # validity.to jako aware datetime


# ---------------------------------------------------------------------------
# Status mapování
# ---------------------------------------------------------------------------

STATUS_MAP = {
    1: "option",
    2: "confirmed",
    3: "cancelled",
    4: "no_show",
    5: "checked_in",
    6: "checked_out",
}

ACTIVE_STATUS_IDS = {1, 2, 5}
CANCELLED_STATUS_IDS = {3, 4}


# ---------------------------------------------------------------------------
# Klient
# ---------------------------------------------------------------------------

class PrevioClient:

    TIMEOUT_SECONDS = 30
    DATETIME_FMT = "%Y-%m-%d %H:%M:%S"

    def __init__(self):
        # XML session – credentials v těle
        self._xml_session = requests.Session()
        self._xml_session.headers.update({
            "Content-Type": "application/xml; charset=utf-8",
            "Accept": "application/xml, text/xml",
        })

        # REST session – HTTP Basic Auth + hotel ID header
        self._rest_session = requests.Session()
        self._rest_session.auth = HTTPBasicAuth(config.PREVIO_USERNAME, config.PREVIO_PASSWORD)
        self._rest_session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Previo-Hotel-ID": str(config.PREVIO_HOTEL_ID),
        })

    # ------------------------------------------------------------------
    # XML API – searchReservations
    # ------------------------------------------------------------------

    def search_reservations(
        self,
        date_from: datetime,
        date_to: datetime,
        statuses: list = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list:
        """
        Vrátí seznam rezervací v zadaném termínu pobytu.

        Previo filtruje přes <term> (datum pobytu), ne datum modifikace.
        Idempotenci zajišťuje data_fingerprint – beze změny = skip.
        Stránkování: automaticky rekurzivní pokud výsledků == limit.
        """
        if statuses is None:
            statuses = [1, 2, 3]

        status_xml = "\n".join(f"        <cosId>{s}</cosId>" for s in statuses)

        xml_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<request>
    <login>{config.PREVIO_USERNAME}</login>
    <password>{config.PREVIO_PASSWORD}</password>
    <hotId>{config.PREVIO_HOTEL_ID}</hotId>
    <term>
        <from>{date_from.strftime('%Y-%m-%d')}</from>
        <to>{date_to.strftime('%Y-%m-%d')}</to>
    </term>
    <statuses>
{status_xml}
    </statuses>
    <limit>
        <offset>{offset}</offset>
        <limit>{limit}</limit>
    </limit>
</request>"""

        url = f"{config.PREVIO_API_URL.rstrip('/')}/hotel/searchReservations"
        logger.debug(f"Previo XML POST searchReservations offset={offset}")

        try:
            resp = self._xml_session.post(
                url, data=xml_body.encode("utf-8"), timeout=self.TIMEOUT_SECONDS
            )
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise PrevioApiError(f"Previo XML API nedostupné: {e}") from e
        except requests.exceptions.Timeout as e:
            raise PrevioApiError(f"Previo XML API timeout: {e}") from e
        except requests.exceptions.HTTPError as e:
            raise PrevioApiError(f"Previo XML API HTTP {resp.status_code}: {resp.text[:300]}") from e

        try:
            root = etree.fromstring(resp.content)
        except etree.XMLSyntaxError as e:
            raise PrevioApiError(f"Previo vrátil neplatné XML: {e}") from e

        err = root.find(".//error")
        if err is not None:
            code = err.findtext("code", "")
            msg = err.findtext("message", err.text or "")
            raise PrevioApiError(f"Previo XML chyba [{code}]: {msg}")

        results = self._parse_reservations(root)

        if len(results) == limit:
            logger.debug(f"Stránkování: načítám offset {offset + limit}")
            results.extend(
                self.search_reservations(date_from, date_to, statuses, limit, offset + limit)
            )

        return results

    # ------------------------------------------------------------------
    # REST API – card-locking-keys (PIN)
    # ------------------------------------------------------------------

    def get_pin(self, com_id: str) -> PrevioPin:
        """
        Získá PIN a dobu platnosti pro daný comId (= reservationRoomId).

        Endpoint: GET /rest/reservations/rooms/card-locking-keys?reservationRoomId={comId}
        Vrátí první klíč z keys[] (jeden comId = typicky jeden zámek).

        Raises: PrevioApiError pokud keys[] je prázdné nebo PIN chybí.
        """
        url = f"{config.PREVIO_API_URL.rstrip('/')}/rest/reservations/rooms/card-locking-keys"
        logger.debug(f"Previo REST GET card-locking-keys comId={com_id}")

        try:
            resp = self._rest_session.get(
                url,
                params={"reservationRoomId": com_id},
                timeout=self.TIMEOUT_SECONDS,
            )
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise PrevioApiError(f"Previo REST API nedostupné: {e}") from e
        except requests.exceptions.Timeout as e:
            raise PrevioApiError(f"Previo REST API timeout: {e}") from e
        except requests.exceptions.HTTPError as e:
            raise PrevioApiError(
                f"Previo REST API HTTP {resp.status_code} pro comId={com_id}: {resp.text[:300]}"
            ) from e

        try:
            data = resp.json()
        except Exception as e:
            raise PrevioApiError(f"Previo REST vrátil neplatný JSON pro comId={com_id}: {e}") from e

        return self._parse_pin(data, com_id)

    # ------------------------------------------------------------------
    # Parsery
    # ------------------------------------------------------------------

    def _parse_reservations(self, root: etree._Element) -> list:
        reservations = []

        for res_el in root.findall("reservation"):
            com_id = (res_el.findtext("comId") or "").strip()
            res_id = (res_el.findtext("resId") or "").strip()

            if not com_id:
                logger.warning(f"Rezervace bez comId (resId={res_id}) – přeskakuji")
                continue

            status_id_raw = (res_el.findtext("status/statusId") or "0").strip()
            try:
                status_id = int(status_id_raw)
            except ValueError:
                status_id = 0
                logger.warning(f"Neznámý statusId '{status_id_raw}' pro comId={com_id}")

            reservation_status = STATUS_MAP.get(status_id, "unknown")

            guest_el = res_el.find("guest")
            guest_name = None
            if guest_el is not None:
                name = (guest_el.findtext("name") or "").strip()
                if name:
                    guest_name = name
                else:
                    first = (guest_el.findtext("firstName") or "").strip()
                    last = (guest_el.findtext("lastName") or "").strip()
                    combined = f"{first} {last}".strip()
                    guest_name = combined or None

            room_name = (res_el.findtext("object/name") or "").strip() or None
            checkin_dt = self._parse_datetime(res_el.findtext("term/from"))
            checkout_dt = self._parse_datetime(res_el.findtext("term/to"))
            created_at = self._parse_datetime(res_el.findtext("created"))
            alfred_code = (res_el.findtext("alfredCode") or "").strip() or None

            reservations.append(PrevioReservation(
                com_id=com_id,
                res_id=res_id,
                guest_name=guest_name,
                room_name=room_name,
                checkin_dt=checkin_dt,
                checkout_dt=checkout_dt,
                status_id=status_id,
                reservation_status=reservation_status,
                alfred_code=alfred_code,
                created_at=created_at,
            ))

        logger.info(f"Previo: naparsováno {len(reservations)} záznamů")
        return reservations

    @staticmethod
    def _parse_pin(data: dict, com_id: str) -> PrevioPin:
        """
        Naparsuje JSON odpověď card-locking-keys.

        Struktura:
          data.cardData.keys[0].code          – PIN
          data.cardData.keys[0].lockGuestName – název zámku
          data.cardData.keys[0].validity.from – ISO 8601 datetime s TZ
          data.cardData.keys[0].validity.to
        """
        try:
            keys = data["cardData"]["keys"]
        except (KeyError, TypeError):
            raise PrevioApiError(
                f"Neočekávaná struktura PIN odpovědi pro comId={com_id}: {str(data)[:200]}"
            )

        if not keys:
            raise PrevioApiError(f"Previo vrátil prázdný keys[] pro comId={com_id}")

        # Použijeme první klíč; logujeme pokud je jich více (suite, propojené pokoje)
        if len(keys) > 1:
            logger.warning(
                f"comId={com_id} má {len(keys)} klíčů – používám první "
                f"(lockGuestName={keys[0].get('lockGuestName')})"
            )

        key = keys[0]
        pin = (key.get("code") or "").strip()

        if not pin:
            raise PrevioApiError(f"Previo vrátil prázdný PIN (code) pro comId={com_id}")

        lock_name = key.get("lockGuestName") or None

        validity = key.get("validity", {})
        valid_from_raw = validity.get("from", "")
        valid_until_raw = validity.get("to", "")

        valid_from = PrevioClient._parse_iso_datetime(valid_from_raw)
        valid_until = PrevioClient._parse_iso_datetime(valid_until_raw)

        if not valid_from or not valid_until:
            raise PrevioApiError(
                f"Previo vrátil neplatné validity datumy pro comId={com_id}: "
                f"from={valid_from_raw!r} to={valid_until_raw!r}"
            )

        return PrevioPin(
            pin=pin,
            lock_name=lock_name,
            valid_from=valid_from,
            valid_until=valid_until,
        )

    # ------------------------------------------------------------------
    # Pomocné
    # ------------------------------------------------------------------

    @classmethod
    def _parse_datetime(cls, raw) -> Optional[datetime]:
        """Parsuje datetime string z XML ("YYYY-MM-DD HH:MM:SS" nebo "YYYY-MM-DD")."""
        if not raw:
            return None
        raw = raw.strip()
        for fmt in (cls.DATETIME_FMT, "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                pass
        logger.warning(f"Nelze parsovat datetime: '{raw}'")
        return None

    @staticmethod
    def _parse_iso_datetime(raw: str) -> Optional[datetime]:
        """
        Parsuje ISO 8601 datetime s timezone offsetem z REST API.
        Příklad: "2024-12-10T14:00:00+0100"
        Vrátí timezone-aware datetime (zachová původní TZ).
        """
        if not raw:
            return None
        raw = raw.strip()
        # Python 3.7+ fromisoformat nepodporuje +0100 (bez dvojtečky), zkus oba formáty
        for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S"):
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                pass
        # Fallback: oprav "+0100" → "+01:00" pro fromisoformat
        try:
            if len(raw) > 5 and raw[-5] in ("+", "-") and ":" not in raw[-5:]:
                fixed = raw[:-2] + ":" + raw[-2:]
                return datetime.fromisoformat(fixed)
        except ValueError:
            pass
        logger.warning(f"Nelze parsovat ISO datetime: '{raw}'")
        return None


def is_active_previo_status(status_id: int) -> bool:
    return status_id in ACTIVE_STATUS_IDS


def is_cancelled_previo_status(status_id: int) -> bool:
    return status_id in CANCELLED_STATUS_IDS


class PrevioApiError(Exception):
    pass
