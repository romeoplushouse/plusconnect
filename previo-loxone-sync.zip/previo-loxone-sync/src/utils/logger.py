"""
utils/logger.py – centrální logging konfigurace.
PINy se nikdy nesmí logovat v plaintextu.
"""
import logging
import logging.handlers
import os
import re
from src.config import config


class SensitiveDataFilter(logging.Filter):
    """Odstraní z log zpráv hesla a PINy pokud by omylem prošly."""

    # Pattern pro PIN (číselné sekvence 2-8 číslic v kontextu 'pin=...')
    _PIN_PATTERN = re.compile(r'(pin["\s:=]+)\d{2,8}', re.IGNORECASE)
    # Pattern pro hesla
    _PASS_PATTERN = re.compile(r'(password["\s:=]+)\S+', re.IGNORECASE)

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = self._PIN_PATTERN.sub(r'\1[REDACTED]', record.msg)
            record.msg = self._PASS_PATTERN.sub(r'\1[REDACTED]', record.msg)
        return True


def setup_logger(name: str = "previo_loxone_sync") -> logging.Logger:
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # Už inicializován

    level = getattr(logging, config.LOG_LEVEL.upper(), logging.INFO)
    logger.setLevel(level)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(formatter)

    # File handler s rotací
    log_dir = os.path.dirname(config.LOG_FILE)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    fh = logging.handlers.RotatingFileHandler(
        config.LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=10,
        encoding="utf-8",
    )
    fh.setLevel(level)
    fh.setFormatter(formatter)

    sensitive_filter = SensitiveDataFilter()
    ch.addFilter(sensitive_filter)
    fh.addFilter(sensitive_filter)

    logger.addHandler(ch)
    logger.addHandler(fh)

    return logger


logger = setup_logger()
