"""
utils/helpers.py – pomocné funkce pro fingerprinting a hashování.
"""
import hashlib
from datetime import datetime
from typing import Optional


def compute_data_fingerprint(
    reservation_id: str,
    reservation_status: str,
    checkin_date: Optional[str],
    checkout_date: Optional[str],
    guest_name: Optional[str],
    room_identifier: Optional[str],
    com_id: Optional[str],
) -> str:
    """
    Vypočítá SHA-256 fingerprint klíčových polí rezervace.
    Pokud se fingerprint nezmění, sync přeskočí rezervaci.
    """
    raw = "|".join([
        str(reservation_id),
        str(reservation_status),
        str(checkin_date or ""),
        str(checkout_date or ""),
        str(guest_name or ""),
        str(room_identifier or ""),
        str(com_id or ""),
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def compute_pin_fingerprint(pin: str, valid_from: Optional[datetime], valid_until: Optional[datetime]) -> str:
    """
    Fingerprint PIN + validita. Změna = je nutné aktualizovat v Loxone.
    PIN se hashuje – nikdy se neuloží v plaintextu.
    """
    raw = "|".join([
        hashlib.sha256(pin.encode("utf-8")).hexdigest(),
        str(valid_from.isoformat() if valid_from else ""),
        str(valid_until.isoformat() if valid_until else ""),
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def hash_pin(pin: str) -> str:
    """SHA-256 hash PINu pro uložení do DB. Nikdy neukladáme plaintext."""
    return hashlib.sha256(pin.encode("utf-8")).hexdigest()


def is_active_reservation(status: str) -> bool:
    """Vrátí True pokud je rezervace aktivní (ne zrušená)."""
    return status.lower() not in ("cancelled", "canceled", "no_show", "noshow", "storno")


def checkin_to_datetime(date_str: Optional[str]) -> Optional[datetime]:
    """Převede ISO date string na datetime (začátek dne)."""
    if not date_str:
        return None
    for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(date_str, fmt).replace(hour=14, minute=0, second=0)
        except ValueError:
            pass
    return None


def checkout_to_datetime(date_str: Optional[str]) -> Optional[datetime]:
    """Převede ISO date string na datetime (konec dne = 12:00 checkout)."""
    if not date_str:
        return None
    for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(date_str, fmt).replace(hour=12, minute=0, second=0)
        except ValueError:
            pass
    return None
