"""
loxone/client.py – HTTP klient pro Loxone PMS & Access API.

Dokumentace: pms-access-api.zip / Loxone UserManagement v16.0
Base URL: https://{miniserver-ip}/jdev/sps/
Autentizace: HTTP Basic Auth nebo JWT Bearer.

Klíčové endpointy použité v této integraci:
  GET  /getgrouplist
  POST /configureuser         (tělo: UserConfiguration JSON)
  GET  /configureuser?userjson={...}  (alternativa pro GET)

Hesla / PINy se hashují před odesláním:
  SHA256({password}:{salt}).toUpperCase()
  salt se získá z: GET /jdev/sys/getkey2/{username}
"""
import hashlib
import json
import urllib.parse
from dataclasses import dataclass
from datetime import datetime
from typing import Optional
import requests
from requests.auth import HTTPBasicAuth

from src.config import config
from src.utils.logger import logger


# ---------------------------------------------------------------------------
# Datové třídy
# ---------------------------------------------------------------------------

@dataclass
class LoxoneUser:
    uuid: str
    name: str
    user_state: int
    valid_from: Optional[int] = None
    valid_until: Optional[int] = None


# ---------------------------------------------------------------------------
# Klient
# ---------------------------------------------------------------------------

class LoxoneClient:
    """
    Klient pro Loxone Miniserver – PMS & Access API.

    Všechny endpointy jsou relativní k /jdev/sps/.
    Hesla se NIKDY neodesílají v plaintextu – vždy hashujeme.
    """

    # Loxone počítá časy od 1.1.2009 00:00:00 UTC
    LOXONE_EPOCH = datetime(2009, 1, 1, 0, 0, 0)
    TIMEOUT_SECONDS = 30

    def __init__(self):
        self._session = requests.Session()
        self._session.auth = HTTPBasicAuth(config.LOXONE_USERNAME, config.LOXONE_PASSWORD)
        self._session.headers.update({"Accept": "application/json"})
        # Ignoruj self-signed certifikát na lokálním Miniseveru
        # V produkci nastav verify=True pokud máš platný cert
        self._verify_ssl = False
        if not self._verify_ssl:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def _get(self, path: str, params: dict = None) -> dict:
        """GET request na Loxone API. Vrátí naparsovaný JSON."""
        url = f"{config.LOXONE_BASE_URL}/jdev/sps/{path.lstrip('/')}"
        logger.debug(f"Loxone GET {path}")
        try:
            resp = self._session.get(url, params=params, timeout=self.TIMEOUT_SECONDS, verify=self._verify_ssl)
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise LoxoneApiError(f"Loxone nedostupný: {e}") from e
        except requests.exceptions.Timeout as e:
            raise LoxoneApiError(f"Loxone timeout: {e}") from e
        except requests.exceptions.HTTPError as e:
            raise LoxoneApiError(f"Loxone HTTP {resp.status_code}: {resp.text[:200]}") from e

        return self._parse_response(resp, path)

    def _post(self, path: str, body: dict) -> dict:
        """POST request na Loxone API s JSON tělem."""
        url = f"{config.LOXONE_BASE_URL}/jdev/sps/{path.lstrip('/')}"
        logger.debug(f"Loxone POST {path}")
        try:
            resp = self._session.post(
                url,
                json=body,
                timeout=self.TIMEOUT_SECONDS,
                verify=self._verify_ssl,
            )
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise LoxoneApiError(f"Loxone nedostupný: {e}") from e
        except requests.exceptions.Timeout as e:
            raise LoxoneApiError(f"Loxone timeout: {e}") from e
        except requests.exceptions.HTTPError as e:
            raise LoxoneApiError(f"Loxone HTTP {resp.status_code}: {resp.text[:200]}") from e

        return self._parse_response(resp, path)

    def _parse_response(self, resp: requests.Response, path: str) -> dict:
        """Naparsuje Loxone JSON odpověď. Kontroluje LL.Code."""
        try:
            data = resp.json()
        except Exception:
            raise LoxoneApiError(f"Loxone vrátil neplatný JSON z {path}: {resp.text[:200]}")

        ll = data.get("LL", {})
        code = str(ll.get("Code", "200"))

        if code not in ("200", "201"):
            raise LoxoneApiError(f"Loxone chyba [{code}] na {path}: {ll.get('value', '')}")

        # value bývá JSON string – pokus o deserializaci
        value = ll.get("value", "")
        if isinstance(value, str) and value.strip().startswith(("{", "[")):
            try:
                ll["value_parsed"] = json.loads(value)
            except json.JSONDecodeError:
                ll["value_parsed"] = None
        else:
            ll["value_parsed"] = None

        return ll

    # ------------------------------------------------------------------
    # Hesla / hashování
    # ------------------------------------------------------------------

    def _get_salt(self, username: str) -> tuple[str, str]:
        """
        Získá salt a hashAlg pro daného uživatele.
        Vrátí (salt, hashAlg) – hashAlg je typicky "SHA256".
        Endpoint: GET /jdev/sys/getkey2/{username}
        """
        url = f"{config.LOXONE_BASE_URL}/jdev/sys/getkey2/{urllib.parse.quote(username)}"
        try:
            resp = self._session.get(url, timeout=self.TIMEOUT_SECONDS, verify=self._verify_ssl)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise LoxoneApiError(f"Nelze získat salt pro {username}: {e}") from e

        data = resp.json()
        ll = data.get("LL", {})
        value = ll.get("value", "")

        # value je "salt,hashAlg,key"
        parts = value.split(",")
        if len(parts) < 2:
            raise LoxoneApiError(f"Neočekávaný formát getkey2 odpovědi: {value}")

        salt = parts[0]
        hash_alg = parts[1].strip()
        return salt, hash_alg

    def hash_password(self, username: str, password: str) -> str:
        """
        Zahashuje heslo dle Loxone specifikace:
          SHA256({password}:{salt}).toUpperCase()
        """
        salt, hash_alg = self._get_salt(username)
        raw = f"{password}:{salt}"
        if hash_alg.upper() == "SHA256":
            return hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
        else:
            raise LoxoneApiError(f"Nepodporovaný hashAlg: {hash_alg}")

    # ------------------------------------------------------------------
    # Uživatelské skupiny
    # ------------------------------------------------------------------

    def get_group_list(self) -> list[dict]:
        """Vrátí seznam všech skupin."""
        ll = self._get("getgrouplist")
        parsed = ll.get("value_parsed")
        if isinstance(parsed, list):
            return parsed
        return []

    # ------------------------------------------------------------------
    # Správa uživatelů
    # ------------------------------------------------------------------

    def create_or_update_user(
        self,
        name: str,
        pin: str,
        valid_from: datetime,
        valid_until: datetime,
        group_uuids: list[str],
        existing_uuid: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> str:
        """
        Vytvoří nebo aktualizuje uživatele v Loxone přes POST /configureuser.

        Parametry:
            name:           Jméno uživatele (guest_name)
            pin:            Číselný PIN 2–8 číslic v plaintextu (odešleme unhashed – Loxone si hashuje sám)
            valid_from:     Začátek platnosti přístupu
            valid_until:    Konec platnosti přístupu
            group_uuids:    Seznam UUID skupin
            existing_uuid:  UUID existujícího uživatele (pokud aktualizujeme)
            user_id:        Volitelné externí ID (reservation_id)

        Vrátí: UUID vytvořeného/aktualizovaného uživatele
        """
        # Loxone ukládá časy jako sekundy od 1.1.2009
        from_ts = self._to_loxone_timestamp(valid_from)
        until_ts = self._to_loxone_timestamp(valid_until)

        # Sestav user payload
        user_payload: dict = {
            "name": name,
            "userState": 4,              # 4 = enabled with timespan (validFrom + validUntil)
            "validFrom": from_ts,
            "validUntil": until_ts,
            "isAdmin": False,
            "changePassword": False,
            "userRights": 0,             # Jen přístup kartou/PINem, žádná app práva
            "usergroups": [{"uuid": uuid} for uuid in group_uuids],
            "keycodes": [{"code": pin}], # PIN se odesílá jako plaintext – Loxone hashuje sám
        }

        if existing_uuid:
            user_payload["uuid"] = existing_uuid

        if user_id:
            user_payload["userid"] = str(user_id)

        ll = self._post("configureuser", user_payload)

        # Získej UUID z odpovědi
        parsed = ll.get("value_parsed")
        if isinstance(parsed, dict):
            uuid = parsed.get("uuid")
        else:
            # Zkus parsovat value string
            value_str = ll.get("value", "")
            try:
                parsed2 = json.loads(value_str)
                uuid = parsed2.get("uuid")
            except Exception:
                uuid = None

        if not uuid:
            if existing_uuid:
                return existing_uuid  # Update proběhl, uuid se nezměnilo
            raise LoxoneApiError("Loxone nevrátil UUID po vytvoření uživatele")

        return uuid

    def deactivate_user(self, loxone_uuid: str) -> None:
        """
        Deaktivuje uživatele (userState=1 = disabled).
        Používá se při zrušení nebo no-show rezervace.
        """
        # Nejprve získej aktuální stav uživatele
        current = self._get_user(loxone_uuid)

        update_payload = {
            "uuid": loxone_uuid,
            "name": current.get("name", ""),
            "userState": 1,  # disabled
            "isAdmin": False,
            "userRights": current.get("userRights", 0),
            "usergroups": current.get("usergroups", []),
        }

        self._post("configureuser", update_payload)
        logger.info(f"Loxone uživatel {loxone_uuid} deaktivován")

    def _get_user(self, loxone_uuid: str) -> dict:
        """Získá detail uživatele. Vrátí dict nebo prázdný dict."""
        try:
            ll = self._get(f"getuser/{loxone_uuid}")
            parsed = ll.get("value_parsed")
            if isinstance(parsed, dict):
                return parsed
        except LoxoneApiError:
            pass
        return {}

    # ------------------------------------------------------------------
    # Přístupový PIN (keycode)
    # ------------------------------------------------------------------

    def update_user_pin(self, loxone_uuid: str, new_pin: str) -> None:
        """
        Aktualizuje PIN uživatele.
        PIN se odesílá jako plaintext – Loxone si hashuje sám přes updateuseraccesscode.
        Endpoint: GET /jdev/sps/updateuseraccesscode/{uuid}/{pin}

        Vrátí kód 200 = PIN nastaven a je unikátní
                  201 = PIN nastaven ale není unikátní (pozor!)
                  409 = PIN je již použit jiným NFC tagem
                  429 = brute-force ochrana
        """
        ll = self._get(f"updateuseraccesscode/{loxone_uuid}/{new_pin}")
        code = str(ll.get("Code", "200"))

        if code == "201":
            logger.warning(
                f"PIN pro uživatele {loxone_uuid} nastaven, ale není unikátní (Code 201). "
                f"Jiný uživatel může mít stejný PIN."
            )
        elif code == "409":
            raise LoxoneApiError(f"PIN je již použit jiným NFC tagem (Code 409)")
        elif code == "429":
            raise LoxoneApiError(f"Brute-force ochrana aktivní – počkej před dalším pokusem (Code 429)")

    # ------------------------------------------------------------------
    # Pomocné metody
    # ------------------------------------------------------------------

    @classmethod
    def _to_loxone_timestamp(cls, dt: datetime) -> int:
        """Převede datetime na sekundy od 1.1.2009 (Loxone epoch)."""
        delta = dt - cls.LOXONE_EPOCH
        return max(0, int(delta.total_seconds()))

    @staticmethod
    def ping(self) -> bool:
        """Zkontroluje dostupnost Miniseveru."""
        try:
            url = f"{config.LOXONE_BASE_URL}/jdev/cfg/apiKey"
            resp = self._session.get(url, timeout=5, verify=self._verify_ssl)
            return resp.status_code == 200
        except Exception:
            return False


class LoxoneApiError(Exception):
    """Výjimka pro chyby Loxone API."""
    pass
