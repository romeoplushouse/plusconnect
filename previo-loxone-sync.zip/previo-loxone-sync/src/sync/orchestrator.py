"""
sync/orchestrator.py – hlavní synchronizační smyčka.

Klíčová změna oproti původnímu návrhu:
  - Previo filtruje POUZE přes datum pobytu (<term>), ne datum modifikace
  - Táhneme klouzavé okno: dnešek až dnešek + LOOKAHEAD_DAYS (default 90)
  - Idempotenci zajišťuje data_fingerprint – beze změny = skip
  - Primární klíč je comId (= jeden pokoj jedné rezervace)
  - Více comId může sdílet stejné resId (rezervace více pokojů najednou)

Workflow pro každý sync run:
  1. Vytvoř SyncRun záznam
  2. Načti rezervace z Previo (klouzavé okno pobytu)
  3. Pro každý comId: CREATE / UPDATE / CANCEL / SKIP
  4. Zpracuj retry frontu
  5. Uzavři SyncRun
"""
import traceback
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from src.config import config
from src.db.database import get_session
from src.db.models import Reservation, SyncRun, AuditLog
from src.loxone.client import LoxoneClient, LoxoneApiError
from src.previo.client import (
    PrevioClient, PrevioApiError, PrevioReservation,
    is_active_previo_status, is_cancelled_previo_status,
)
from src.utils.helpers import (
    compute_data_fingerprint,
    compute_pin_fingerprint,
    hash_pin,
)
from src.utils.logger import logger

# Jak daleko dopředu sledujeme rezervace (dny)
LOOKAHEAD_DAYS = int(__import__("os").getenv("SYNC_LOOKAHEAD_DAYS", "90"))


class SyncOrchestrator:

    def __init__(self):
        self.previo = PrevioClient()
        self.loxone = LoxoneClient()

    # ------------------------------------------------------------------
    # Hlavní vstupní bod
    # ------------------------------------------------------------------

    def run_sync(self) -> SyncRun:
        """Spustí jeden sync cyklus. Idempotentní – bezpečné volat opakovaně."""
        db = get_session()
        sync_run = None

        try:
            window_from, window_to = self._compute_window()
            logger.info(f"Sync start: pobyt {window_from.date()} → {window_to.date()}")

            sync_run = SyncRun(
                window_from=window_from,
                window_to=window_to,
                status="running",
            )
            db.add(sync_run)
            db.commit()

            # 1. Načti z Previo
            try:
                reservations = self.previo.search_reservations(window_from, window_to)
                sync_run.count_fetched = len(reservations)
            except PrevioApiError as e:
                logger.error(f"Previo API nedostupné: {e}")
                sync_run.status = "failed"
                sync_run.error_detail = str(e)
                sync_run.finished_at = datetime.utcnow()
                db.commit()
                return sync_run

            # 2. Zpracuj každý comId
            for res in reservations:
                self._process_reservation(db, res, sync_run)

            # 3. Retry fronta
            self._process_retries(db, sync_run)

            # 4. Uzavři run
            sync_run.finished_at = datetime.utcnow()
            sync_run.status = "success" if sync_run.count_failed == 0 else "partial_failure"
            db.commit()

            logger.info(
                f"Sync dokončen [{sync_run.status}]: "
                f"fetched={sync_run.count_fetched} "
                f"created={sync_run.count_created} "
                f"updated={sync_run.count_updated} "
                f"cancelled={sync_run.count_cancelled} "
                f"skipped={sync_run.count_skipped} "
                f"failed={sync_run.count_failed}"
            )
            return sync_run

        except Exception as e:
            logger.error(f"Kritická chyba v sync: {e}\n{traceback.format_exc()}")
            if sync_run:
                sync_run.status = "failed"
                sync_run.error_detail = f"{type(e).__name__}: {e}"
                sync_run.finished_at = datetime.utcnow()
                db.commit()
            raise
        finally:
            db.close()

    # ------------------------------------------------------------------
    # Zpracování jednoho záznamu (comId)
    # ------------------------------------------------------------------

    def _process_reservation(
        self, db: Session, res: PrevioReservation, sync_run: SyncRun
    ) -> None:
        """Rozhodne CREATE / UPDATE / CANCEL / SKIP a provede akci."""
        try:
            fingerprint = compute_data_fingerprint(
                reservation_id=res.com_id,
                reservation_status=res.reservation_status,
                checkin_date=res.checkin_dt.isoformat() if res.checkin_dt else None,
                checkout_date=res.checkout_dt.isoformat() if res.checkout_dt else None,
                guest_name=res.guest_name,
                room_identifier=res.room_name,
                com_id=res.com_id,
            )

            existing: Optional[Reservation] = (
                db.query(Reservation)
                .filter(Reservation.reservation_id == res.com_id)
                .first()
            )

            if existing is None:
                if is_active_previo_status(res.status_id):
                    self._create_user(db, res, fingerprint, sync_run)
                else:
                    # Přišla zrušená rezervace kterou jsme neviděli – ignoruj
                    logger.debug(f"Nový zrušený comId {res.com_id} – ignoruji")
                    sync_run.count_skipped += 1

            elif existing.data_fingerprint == fingerprint:
                logger.debug(f"comId {res.com_id} beze změn – skip")
                sync_run.count_skipped += 1

            else:
                if is_cancelled_previo_status(res.status_id):
                    if existing.sync_status != "cancelled_synced":
                        self._cancel_user(db, existing, res, fingerprint, sync_run)
                    else:
                        sync_run.count_skipped += 1
                elif is_active_previo_status(res.status_id):
                    self._update_user(db, existing, res, fingerprint, sync_run)
                else:
                    # Neznámý status – jen aktualizuj fingerprint, nezasahuj do Loxone
                    logger.warning(
                        f"comId {res.com_id} má neznámý statusId={res.status_id} "
                        f"({res.reservation_status}) – aktualizuji DB, ale Loxone nechávám beze změn"
                    )
                    existing.data_fingerprint = fingerprint
                    existing.reservation_status = res.reservation_status
                    db.commit()
                    sync_run.count_skipped += 1

        except Exception as e:
            logger.error(f"Neočekávaná chyba pro comId {res.com_id}: {e}")
            sync_run.count_failed += 1

    # ------------------------------------------------------------------
    # CREATE
    # ------------------------------------------------------------------

    def _create_user(
        self, db: Session, res: PrevioReservation, fingerprint: str, sync_run: SyncRun
    ) -> None:
        """Vytvoří nového Loxone uživatele pro hosta."""
        record = Reservation(
            reservation_id=res.com_id,       # com_id = primární klíč
            booking_id=res.res_id,            # resId = ID skupiny rezervace
            com_id=res.com_id,
            guest_name=res.guest_name,
            room_identifier=res.room_name,
            checkin_date=res.checkin_dt.strftime("%Y-%m-%d %H:%M:%S") if res.checkin_dt else None,
            checkout_date=res.checkout_dt.strftime("%Y-%m-%d %H:%M:%S") if res.checkout_dt else None,
            reservation_status=res.reservation_status,
            data_fingerprint=fingerprint,
            sync_status="pending",
        )
        db.add(record)
        db.flush()

        # Získej PIN
        try:
            previo_pin = self.previo.get_pin(res.com_id)
        except PrevioApiError as e:
            logger.warning(f"Nelze získat PIN pro comId={res.com_id}: {e}")
            record.sync_status = "sync_failed"
            record.last_error = f"pin_fetch_failed: {e}"
            record.retry_count = 0
            record.next_retry_at = self._next_retry_at(0)
            db.commit()
            sync_run.count_failed += 1
            return

        if not previo_pin.pin:
            record.sync_status = "sync_failed"
            record.last_error = "empty_pin"
            record.retry_count = 0
            record.next_retry_at = self._next_retry_at(0)
            db.commit()
            sync_run.count_failed += 1
            return

        # Časy platnosti: PIN z Previo má přednost, fallback = checkin/checkout
        valid_from = previo_pin.valid_from or res.checkin_dt
        valid_until = previo_pin.valid_until or res.checkout_dt

        if not valid_from or not valid_until:
            logger.warning(f"comId {res.com_id}: chybí čas platnosti")
            record.sync_status = "sync_failed"
            record.last_error = "missing_validity_dates"
            db.commit()
            sync_run.count_failed += 1
            return

        # Vytvoř v Loxone
        try:
            display_name = res.guest_name or f"Guest_{res.com_id}"
            loxone_uuid = self.loxone.create_or_update_user(
                name=display_name,
                pin=previo_pin.pin,
                valid_from=valid_from,
                valid_until=valid_until,
                group_uuids=[config.LOXONE_GUEST_GROUP_UUID],
                user_id=res.com_id,
            )
        except LoxoneApiError as e:
            logger.error(f"Loxone chyba CREATE comId={res.com_id}: {e}")
            record.sync_status = "sync_failed"
            record.last_error = str(e)
            record.retry_count = 0
            record.next_retry_at = self._next_retry_at(0)
            db.commit()
            sync_run.count_failed += 1
            return

        record.loxone_user_uuid = loxone_uuid
        record.pin_hash = hash_pin(previo_pin.pin)
        record.pin_valid_from = int((valid_from - datetime(1970, 1, 1)).total_seconds())
        record.pin_valid_until = int((valid_until - datetime(1970, 1, 1)).total_seconds())
        record.pin_fingerprint = compute_pin_fingerprint(previo_pin.pin, valid_from, valid_until)
        record.sync_status = "synced"
        record.last_sync_at = datetime.utcnow()
        record.last_error = None
        record.retry_count = 0

        self._audit(db, res.com_id, loxone_uuid, "CREATE_USER", None, record.pin_fingerprint, "success",
                    detail=f"room={res.room_name} checkin={res.checkin_dt}")

        db.commit()
        sync_run.count_created += 1
        logger.info(
            f"CREATE comId={res.com_id} loxone={loxone_uuid} "
            f"guest='{display_name}' room='{res.room_name}' "
            f"from={valid_from} until={valid_until}"
        )

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------

    def _update_user(
        self, db: Session, record: Reservation, res: PrevioReservation,
        fingerprint: str, sync_run: SyncRun
    ) -> None:
        """Aktualizuje existujícího Loxone uživatele."""
        try:
            previo_pin = self.previo.get_pin(res.com_id)
        except PrevioApiError as e:
            self._mark_failed(db, record, f"pin_fetch_failed: {e}")
            sync_run.count_failed += 1
            return

        valid_from = previo_pin.valid_from or res.checkin_dt
        valid_until = previo_pin.valid_until or res.checkout_dt

        if not valid_from or not valid_until:
            self._mark_failed(db, record, "missing_validity_dates")
            sync_run.count_failed += 1
            return

        new_pin_fp = compute_pin_fingerprint(previo_pin.pin, valid_from, valid_until)
        pin_changed = (new_pin_fp != record.pin_fingerprint)

        try:
            self.loxone.create_or_update_user(
                name=res.guest_name or f"Guest_{res.com_id}",
                pin=previo_pin.pin,
                valid_from=valid_from,
                valid_until=valid_until,
                group_uuids=[config.LOXONE_GUEST_GROUP_UUID],
                existing_uuid=record.loxone_user_uuid,
                user_id=res.com_id,
            )
        except LoxoneApiError as e:
            logger.error(f"Loxone chyba UPDATE comId={res.com_id}: {e}")
            self._mark_failed(db, record, str(e))
            sync_run.count_failed += 1
            return

        old_fp = record.pin_fingerprint
        record.data_fingerprint = fingerprint
        record.pin_fingerprint = new_pin_fp
        record.pin_hash = hash_pin(previo_pin.pin)
        record.reservation_status = res.reservation_status
        record.checkin_date = res.checkin_dt.strftime("%Y-%m-%d %H:%M:%S") if res.checkin_dt else None
        record.checkout_date = res.checkout_dt.strftime("%Y-%m-%d %H:%M:%S") if res.checkout_dt else None
        record.guest_name = res.guest_name
        record.room_identifier = res.room_name
        record.pin_valid_from = int((valid_from - datetime(1970, 1, 1)).total_seconds())
        record.pin_valid_until = int((valid_until - datetime(1970, 1, 1)).total_seconds())
        record.sync_status = "synced"
        record.last_sync_at = datetime.utcnow()
        record.last_error = None
        record.retry_count = 0

        action = "PIN_CHANGED" if pin_changed else "VALIDITY_CHANGED"
        self._audit(db, res.com_id, record.loxone_user_uuid, action, old_fp, new_pin_fp, "success")

        db.commit()
        sync_run.count_updated += 1
        logger.info(f"UPDATE comId={res.com_id} action={action}")

    # ------------------------------------------------------------------
    # CANCEL
    # ------------------------------------------------------------------

    def _cancel_user(
        self, db: Session, record: Reservation, res: PrevioReservation,
        fingerprint: str, sync_run: SyncRun
    ) -> None:
        """Deaktivuje Loxone uživatele při zrušení rezervace."""
        if record.loxone_user_uuid:
            try:
                self.loxone.deactivate_user(record.loxone_user_uuid)
            except LoxoneApiError as e:
                logger.error(f"Nelze deaktivovat {record.loxone_user_uuid}: {e}")
                self._mark_failed(db, record, str(e))
                sync_run.count_failed += 1
                return

        record.data_fingerprint = fingerprint
        record.reservation_status = res.reservation_status
        record.sync_status = "cancelled_synced"
        record.last_sync_at = datetime.utcnow()
        record.last_error = None

        self._audit(db, res.com_id, record.loxone_user_uuid, "CANCEL_ACCESS",
                    None, None, "success", detail=f"statusId={res.status_id}")

        db.commit()
        sync_run.count_cancelled += 1
        logger.info(
            f"CANCEL comId={res.com_id} loxone={record.loxone_user_uuid} "
            f"status={res.reservation_status}"
        )

    # ------------------------------------------------------------------
    # Retry fronta
    # ------------------------------------------------------------------

    def _process_retries(self, db: Session, sync_run: SyncRun) -> None:
        now = datetime.utcnow()
        retry_records = (
            db.query(Reservation)
            .filter(
                Reservation.sync_status == "sync_failed",
                Reservation.next_retry_at <= now,
                Reservation.retry_count < config.SYNC_MAX_RETRY_COUNT,
            )
            .all()
        )

        if retry_records:
            logger.info(f"Retry fronta: {len(retry_records)} záznamů")

        for record in retry_records:
            res = PrevioReservation(
                com_id=record.com_id or record.reservation_id,
                res_id=record.booking_id or "",
                guest_name=record.guest_name,
                room_name=record.room_identifier,
                checkin_dt=self._parse_stored_dt(record.checkin_date),
                checkout_dt=self._parse_stored_dt(record.checkout_date),
                status_id=2,  # předpokládáme confirmed při retry
                reservation_status=record.reservation_status or "confirmed",
                alfred_code=None,
                created_at=None,
            )

            fingerprint = compute_data_fingerprint(
                reservation_id=res.com_id,
                reservation_status=res.reservation_status,
                checkin_date=res.checkin_dt.isoformat() if res.checkin_dt else None,
                checkout_date=res.checkout_dt.isoformat() if res.checkout_dt else None,
                guest_name=res.guest_name,
                room_identifier=res.room_name,
                com_id=res.com_id,
            )

            if record.loxone_user_uuid:
                self._update_user(db, record, res, fingerprint, sync_run)
            else:
                self._create_user(db, res, fingerprint, sync_run)

            db.refresh(record)
            if record.sync_status == "sync_failed":
                record.retry_count += 1
                record.next_retry_at = self._next_retry_at(record.retry_count)
                if record.retry_count >= config.SYNC_MAX_RETRY_COUNT:
                    record.sync_status = "stale"
                    logger.error(
                        f"comId {record.reservation_id} dosáhl max retries – označen STALE, "
                        f"potřeba manuální kontroly."
                    )
                db.commit()

    # ------------------------------------------------------------------
    # Pomocné metody
    # ------------------------------------------------------------------

    def _compute_window(self) -> tuple:
        """
        Klouzavé okno: dnešek → dnešek + LOOKAHEAD_DAYS.
        Previo filtruje přes datum pobytu, ne modifikace.
        """
        today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        return today, today + timedelta(days=LOOKAHEAD_DAYS)

    def _mark_failed(self, db: Session, record: Reservation, error: str) -> None:
        record.sync_status = "sync_failed"
        record.last_error = error[:1000]
        record.next_retry_at = self._next_retry_at(record.retry_count or 0)
        db.commit()

    @staticmethod
    def _next_retry_at(retry_count: int) -> datetime:
        backoff = config.RETRY_BACKOFF_SECONDS
        delay = backoff[min(retry_count, len(backoff) - 1)]
        return datetime.utcnow() + timedelta(seconds=delay)

    @staticmethod
    def _parse_stored_dt(s: Optional[str]) -> Optional[datetime]:
        if not s:
            return None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                pass
        return None

    def _audit(
        self, db: Session,
        reservation_id: str, loxone_uuid: Optional[str],
        action: str, old_hash: Optional[str], new_hash: Optional[str],
        result: str, detail: str = "",
    ) -> None:
        db.add(AuditLog(
            reservation_id=reservation_id,
            loxone_user_uuid=loxone_uuid,
            action=action,
            old_value_hash=old_hash,
            new_value_hash=new_hash,
            result=result,
            detail=detail,
        ))
