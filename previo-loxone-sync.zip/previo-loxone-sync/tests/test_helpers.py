"""
tests/test_helpers.py – unit testy pomocných funkcí.
Nevyžadují žádné API připojení.
"""
import pytest
from datetime import datetime
from src.utils.helpers import (
    compute_data_fingerprint,
    compute_pin_fingerprint,
    hash_pin,
    is_active_reservation,
    checkin_to_datetime,
    checkout_to_datetime,
)


def test_fingerprint_changes_with_status():
    fp1 = compute_data_fingerprint("1", "confirmed", "2025-06-01", "2025-06-05", "Jan Novak", "101", "com123")
    fp2 = compute_data_fingerprint("1", "cancelled", "2025-06-01", "2025-06-05", "Jan Novak", "101", "com123")
    assert fp1 != fp2


def test_fingerprint_stable():
    args = ("1", "confirmed", "2025-06-01", "2025-06-05", "Jan Novak", "101", "com123")
    assert compute_data_fingerprint(*args) == compute_data_fingerprint(*args)


def test_pin_fingerprint_changes_with_pin():
    dt1 = datetime(2025, 6, 1)
    dt2 = datetime(2025, 6, 5)
    fp1 = compute_pin_fingerprint("1234", dt1, dt2)
    fp2 = compute_pin_fingerprint("5678", dt1, dt2)
    assert fp1 != fp2


def test_hash_pin_no_plaintext():
    pin = "1234"
    hashed = hash_pin(pin)
    assert pin not in hashed
    assert len(hashed) == 64  # SHA-256 hex


def test_active_reservation():
    assert is_active_reservation("confirmed") is True
    assert is_active_reservation("modified") is True
    assert is_active_reservation("cancelled") is False
    assert is_active_reservation("no_show") is False
    assert is_active_reservation("CANCELLED") is False


def test_checkin_to_datetime():
    dt = checkin_to_datetime("2025-06-01")
    assert dt is not None
    assert dt.hour == 14  # Check-in čas


def test_checkout_to_datetime():
    dt = checkout_to_datetime("2025-06-05")
    assert dt is not None
    assert dt.hour == 12  # Check-out čas


def test_checkin_none():
    assert checkin_to_datetime(None) is None
    assert checkout_to_datetime("") is None
