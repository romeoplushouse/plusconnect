"""
main.py – vstupní bod sync service.

Spuštění:
    python main.py                  # jednorázový sync
    python main.py --daemon         # opakovaný sync každých N sekund
    python main.py --check-health   # otestuj připojení k API
"""
import argparse
import sys
import time

from src.config import config
from src.db.database import init_db
from src.sync.orchestrator import SyncOrchestrator
from src.utils.logger import logger


def run_once() -> int:
    """Provede jeden sync cyklus. Vrátí exit code (0=ok, 1=chyba)."""
    try:
        orchestrator = SyncOrchestrator()
        run = orchestrator.run_sync()
        if run.status == "failed":
            return 1
        return 0
    except Exception as e:
        logger.error(f"Kritická chyba sync: {e}")
        return 1


def run_daemon():
    """Opakuje sync každých SYNC_INTERVAL_SECONDS sekund."""
    logger.info(f"Daemon režim: interval {config.SYNC_INTERVAL_SECONDS}s")
    while True:
        try:
            run_once()
        except Exception as e:
            logger.error(f"Neočekávaná chyba v daemon smyčce: {e}")
        logger.debug(f"Čekám {config.SYNC_INTERVAL_SECONDS}s do dalšího runu...")
        time.sleep(config.SYNC_INTERVAL_SECONDS)


def check_health():
    """Otestuje připojení k oběma API."""
    import requests
    from requests.auth import HTTPBasicAuth

    ok = True

    # Test Loxone
    try:
        url = f"{config.LOXONE_BASE_URL}/jdev/cfg/apiKey"
        resp = requests.get(url, auth=HTTPBasicAuth(config.LOXONE_USERNAME, config.LOXONE_PASSWORD),
                            timeout=10, verify=False)
        if resp.status_code == 200:
            logger.info(f"✓ Loxone Miniserver dostupný ({config.LOXONE_BASE_URL})")
        else:
            logger.error(f"✗ Loxone vrátil HTTP {resp.status_code}")
            ok = False
    except Exception as e:
        logger.error(f"✗ Loxone nedostupný: {e}")
        ok = False

    # Test DB
    try:
        from src.db.database import get_session
        db = get_session()
        db.execute(__import__("sqlalchemy").text("SELECT 1"))
        db.close()
        logger.info(f"✓ Databáze OK ({config.DATABASE_URL.split('//')[0]})")
    except Exception as e:
        logger.error(f"✗ Databáze nedostupná: {e}")
        ok = False

    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description="Previo ↔ Loxone sync service")
    parser.add_argument("--daemon", action="store_true", help="Opakovaný sync v nekonečné smyčce")
    parser.add_argument("--check-health", action="store_true", help="Otestuj připojení k API")
    args = parser.parse_args()

    # Inicializuj DB
    logger.info("Inicializace databáze...")
    init_db()
    logger.info("Databáze připravena.")

    if args.check_health:
        sys.exit(check_health())
    elif args.daemon:
        run_daemon()
    else:
        sys.exit(run_once())


if __name__ == "__main__":
    main()
