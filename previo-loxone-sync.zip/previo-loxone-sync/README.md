# Previo ↔ Loxone Sync Service

Automatická synchronizace rezervací z **Previo PMS** do **Loxone Miniserver**.
Každé rezervaci vytvoří Loxone uživatele s PINem a časově omezeným přístupem.

---

## Architektura

```
Previo XML API  ──→  Sync Service (Python)  ──→  Loxone PMS & Access API
                            │
                        SQLite / PostgreSQL
                        (audit log, retry fronta)
```

**Sync interval:** každých 5 minut (konfigurovatelné)  
**Časové okno:** modified_from/modified_to s 10-minutovým překryvem

---

## Rychlý start na VPS

```bash
git clone <repo> /opt/previo-loxone-sync
cd /opt/previo-loxone-sync

# Instalace
bash setup.sh

# Konfigurace
nano .env

# Test připojení
source .venv/bin/activate
python main.py --check-health

# Jeden test run
python main.py

# Produkční spuštění (systemd)
sudo cp scripts/previo-loxone-sync.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable previo-loxone-sync
sudo systemctl start previo-loxone-sync
sudo systemctl status previo-loxone-sync
```

---

## Konfigurace (.env)

| Proměnná | Popis |
|---|---|
| `PREVIO_API_URL` | URL Previo XML API |
| `PREVIO_USERNAME` | Previo login |
| `PREVIO_PASSWORD` | Previo heslo |
| `PREVIO_HOTEL_ID` | ID hotelu v Previo |
| `LOXONE_BASE_URL` | IP/hostname Miniseveru (https://...) |
| `LOXONE_USERNAME` | Loxone login (musí mít Usermanagement práva) |
| `LOXONE_PASSWORD` | Loxone heslo |
| `LOXONE_GUEST_GROUP_UUID` | UUID skupiny pro hotelové hosty |
| `SYNC_INTERVAL_SECONDS` | Interval sync (default: 300) |
| `DATABASE_URL` | SQLite nebo PostgreSQL connection string |

### Jak zjistit LOXONE_GUEST_GROUP_UUID

```bash
curl -u loxone_user:loxone_pass \
  "https://miniserver-ip/jdev/sps/getgrouplist" -k
```

V odpovědi najdeš skupiny – zkopíruj UUID skupiny určené pro hosty.

---

## Struktura projektu

```
previo-loxone-sync/
├── main.py                    # Vstupní bod
├── .env.example               # Šablona konfigurace
├── requirements.txt
├── setup.sh
├── src/
│   ├── config.py              # Načítání env proměnných
│   ├── previo/
│   │   └── client.py          # Previo XML API klient
│   ├── loxone/
│   │   └── client.py          # Loxone HTTP API klient
│   ├── db/
│   │   ├── models.py          # SQLAlchemy modely
│   │   └── database.py        # Engine, session, init
│   ├── sync/
│   │   └── orchestrator.py    # Hlavní sync logika
│   └── utils/
│       ├── helpers.py         # Fingerprint, hashování
│       └── logger.py          # Logging s maskováním PINů
├── scripts/
│   └── previo-loxone-sync.service  # systemd unit
└── tests/
    └── test_helpers.py
```

---

## Stavy synchronizace

| Stav | Popis |
|---|---|
| `pending` | Čeká na zpracování |
| `synced` | Úspěšně synchronizováno |
| `sync_failed` | Chyba – naplánován retry |
| `cancelled_synced` | Rezervace zrušena, přístup odebrán |
| `stale` | Max retries dosaženo – **vyžaduje manuální kontrolu** |

---

## Důležité poznámky

### Previo XML API adaptace

`src/previo/client.py` obsahuje parser pro XML-RPC formát. Po získání přístupu k Previo sandbox **ověř skutečné názvy XML elementů** a pokud se liší, uprav metody `_parse_reservations()` a `_parse_pin()`.

Klíčové věci k ověření:
- Přesný název metody pro hledání rezervací (`Hotel.searchReservations`)
- Přesný název metody pro PIN (`Hotel.getPin`)
- Názvy XML elementů v odpovědích
- Formát datumů a časů

### Loxone SSL certifikát

Výchozí konfigurace vypíná ověření SSL (`verify=False`) protože Miniservery typicky používají self-signed certifikát. Pokud máš platný certifikát, nastav `verify=True` v `src/loxone/client.py`.

### Bezpečnost PINů

- PINy se **nikdy neukládají v plaintextu** do DB
- V DB je pouze SHA-256 hash PINu
- Logy automaticky maskují PINy přes `SensitiveDataFilter`
- PIN se odesílá do Loxone jako plaintext – Loxone si hashuje sám

---

## Spouštění testů

```bash
source .venv/bin/activate
pip install pytest
pytest tests/ -v
```

---

## Logy

```bash
# Živé logy
tail -f logs/sync.log

# Systemd logy
journalctl -u previo-loxone-sync -f
```
